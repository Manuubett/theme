document.addEventListener("DOMContentLoaded", () => {
    const postTitle = document.getElementById("postTitle");
    const postImage = document.getElementById("postImage");
    const postText = document.getElementById("postText");
    const relatedPostsContainer = document.getElementById("relatedPostsContainer");
    const commentInput = document.getElementById("commentInput");
    const commentButton = document.getElementById("commentButton");
    const commentList = document.getElementById("commentList");

    // Dummy post data (Replace with actual dynamic data later)
    const post = {
        title: "How to Start a Successful Blog",
        image: "assets/images/featured.jpg",
        content: "A complete guide to launching your blog in 2024. Blogging is an excellent way to share knowledge, build an audience, and even make money online..."
    };

    const relatedPosts = [
        { title: "10 Blogging Tips", category: "lifestyle" },
        { title: "SEO Guide for Blogs", category: "tech" },
        { title: "How to Monetize Your Blog", category: "tech" }
    ];

    // Load post data
    postTitle.textContent = post.title;
    postImage.src = post.image;
    postText.textContent = post.content;

    // Load related posts
    relatedPosts.forEach(post => {
        const postElement = document.createElement("div");
        postElement.classList.add("post");
        postElement.innerHTML = `<h3>${post.title}</h3><a href="post.html">Read More</a>`;
        relatedPostsContainer.appendChild(postElement);
    });

    // Handle comments
    commentButton.addEventListener("click", () => {
        if (commentInput.value.trim() !== "") {
            const comment = document.createElement("div");
            comment.classList.add("comment");
            comment.textContent = commentInput.value;
            commentList.appendChild(comment);
            commentInput.value = "";
        } else {
            alert("Please write a comment.");
        }
    });
});
