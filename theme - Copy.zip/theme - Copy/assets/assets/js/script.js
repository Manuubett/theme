document.addEventListener("DOMContentLoaded", () => {
    // Dummy blog posts
    const posts = [
        { title: "Tech Post 1", category: "tech", content: "Introduction to AI..." },
        { title: "Travel Post 1", category: "travel", content: "Best places to visit in 2025..." },
        { title: "Lifestyle Post 1", category: "lifestyle", content: "How to stay productive..." },
        { title: "Tech Post 2", category: "tech", content: "The rise of quantum computing..." }
    ];

    const postGrid = document.querySelector(".post-grid");

    // Render posts dynamically
    function renderPosts() {
        postGrid.innerHTML = "";
        posts.forEach(post => {
            const postElement = document.createElement("div");
            postElement.classList.add("post");
            postElement.innerHTML = `
                <h3>${post.title}</h3>
                <p>${post.content}</p>
                <a href="post.html">Read More</a>
            `;
            postGrid.appendChild(postElement);
        });
    }

    renderPosts();
});
